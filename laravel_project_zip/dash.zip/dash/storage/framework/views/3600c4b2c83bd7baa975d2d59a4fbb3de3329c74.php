<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               <div class="card-header">Product Category</div>

                  <div class="card-body">
                      <form action="<?php echo e(url('product/update')); ?>" method="POST" id="form" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>">
                            <div class="form-group">
                             <label>Product Name</label>
                             <input type="text" name="product_name" class="form-control" value="<?php echo e($product->product_name); ?>">
                             
                            </div>

                            <div class="form-group">
                             <label>Product Description</label>
                             <textarea type="text" name="product_description" class="form-control"><?php echo e($product->product_description); ?></textarea>
                             
                            </div>
                            <div class="form-group">
                                <label for="">File</label>
                                <input type="file" name="image" id="" class="form-control" placeholder="" aria-describedby="helpId">
                            </div>

                            <div class="form-group">
                                <input type="submit" name="submit" value="Update Product">
                            </div>

                      </form>
                  </div>
               </div>
            </div>
        </div>
    </div>
</div>
<script>
 $(document).ready(function() {
      $("#form").validate({
    rules: {
        product_category_name:{
          minlength:3,
        },
      },
    messages: {
        product_category_name: "Please enter atleast 3 character."
    }
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\dash\resources\views/edit_product.blade.php ENDPATH**/ ?>