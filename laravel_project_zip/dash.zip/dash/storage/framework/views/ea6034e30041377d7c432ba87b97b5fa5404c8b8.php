<!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center"> 2021 © Ample Admin brought to you by <a
                href="https://www.wrappixel.com/">wrappixel.com</a>
        </footer>

<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="<?php echo e(asset(' frontend/plugins/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset(' frontend/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset(' frontend/js/app-style-switcher.js')); ?>"></script>
<script src="<?php echo e(asset(' frontend/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
<!--Wave Effects -->
<script src="<?php echo e(asset(' frontend/js/waves.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset(' frontend/js/sidebarmenu.js')); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(asset(' frontend/js/custom.js')); ?>"></script>
<!--This page JavaScript -->
<!--chartis chart-->
<script src="<?php echo e(asset(' frontend/plugins/bower_components/chartist/dist/chartist.min.js')); ?>"></script>
<script src="<?php echo e(asset(' frontend/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js')); ?>"></script>
<script src="<?php echo e(asset(' frontend/js/pages/dashboards/dashboard1.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\dash\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>