<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               <div class="card-header">Product Category</div>

                  <div class="card-body">
                      <hr>
                      <table class="table table-bordered" width="100%">
                          <thead>
                            <td>Product Category</td>
                              <td>Product Name</td>
                              <td>Product image</td>
                              <td>Description</td>
                              <td>Status</td>
                              <td>Action</td>
                          </thead>
                          <tbody>
                              <?php if($product->isNotEmpty()): ?>
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($pro->getCategory->category_name); ?></td>
                                    <td><?php echo e($pro->product_name); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('uploads/'.$pro->image)); ?>" width="70px" height="70px">
                                    </td>

                                    <td><?php echo e($pro->product_description); ?></td>
                                    <td><?php echo e($pro->status); ?></td>
                                    <td style="text-align: center"><a href="<?php echo e(url('product/edit')); ?>/<?php echo e($pro->product_id); ?>" class="btn btn-primary">Update</a>
                                        <a href="<?php echo e(url('product/delete')); ?>/<?php echo e($pro->product_id); ?>" class="btn btn-danger">Delete</a>
                                    </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                          </tbody>
                      </table>

                  </div>
               </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\dash\resources\views/table.blade.php ENDPATH**/ ?>