<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb bg-white">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h3 class="page-title">Products</h3>
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                    <div class="card-header"><h2>Product</h2> </div>

                        <div class="card-body">

                            <h3>Add Product</h3>
                            <form action="<?php echo e(url('product\store')); ?>" method="POST" id="form" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="category">Category </label>

                                    <select class="form-control" name="category_id">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </select>
                                    
                                    
                                </div>

                                <div class="form-group">
                                    <label>Product Name</label>
                                    <input type="text" name="product_name" class="form-control" placeholder="Product Name">
                                    <small class="text-danger"><?php echo e($errors->first('product name')); ?></small>
                                    </div>

                                    <div class="form-group">
                                    <label>Product Description</label>
                                    <textarea type="text" name="product_description" class="form-control"></textarea>
                                    
                                    </div>
                                    <div class="form-group">
                                        <label for="">File</label>
                                        <input type="file" name="image" id="" class="form-control" placeholder="" aria-describedby="helpId">
                                    </div>

                                    <div class="form-group">
                                        <input type="submit" name="submit" value="Insert Product">
                                    </div>

                            </form>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\dash\resources\views/product.blade.php ENDPATH**/ ?>