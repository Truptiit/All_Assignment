<?php

namespace App\Traits;
use App\Models\CategoryModel;

trait CommonTrait {
    public function getCategory($category_id) {
        $category = CategoryModel::where('category_id',$category_id)->first();
        return $category;
    }
}
