<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductModel;
use App\Models\CategoryModel;

use App\Traits\CommonTrait;

class ProductController extends Controller
{
    use CommonTrait;

    public function index(){
        // $categoryData = $this->getCategory(2);
        // dd($categoryData);
        $product = CategoryModel::get(); //use CategoryModel to get data from category table
        //dd($product);
        return view('product',compact('product'));
    }


    public function in(){
        return view('dashboard');
    }

    public function table(){
        //$product = ProductModel::join('category','category.category_id','product.category_id')->get();
        $product = ProductModel::with('getcategory')->get();
        return view('table',compact('product'));
    }


    public function store(Request $request)
    {
        $input = $request->all();
        $this->validate($request,[
            'product_name'=>'required'

        ]);

        $product=new ProductModel;
        $product->product_name=$request->input('product_name');
        $product->product_description=$request->input('product_description');
        $product->category_id=$request->input('category_id');
        //dd($product);

        if($request->hasfile('image'))
        {
            $filename=time().".".$request->file('image')->getClientOriginalExtension();
            $request->file('image')->move('uploads',$filename);
            $product->image=$filename;
            // $input['image'] = $filename;
        }

        // $this->validate($request,[
        //     'product_name'=>'required|min:3',
        // ]);

        //$product->product_description=$request->input('product_description');
        $product->save();
        // ProductModel::create($input);
        toastr()->success('Product Inserted');
        return  redirect('table');
    }



    public function edit($id)
    {
        // dd($id);
        // $product = ProductCategory::find($id);
        // dd($product);
        $product= ProductModel::where('product_id',$id)->first();
        return view('edit_product',compact('product'));
        // return view('edit_product');
    }

    public function update(Request $request)
    {
        $input = $request->all();
        // $product = ProductCategory::find($request->product_category_id);
        // $product = ProductCategory::find($input['product_category_id']);

        //method 2
        unset($input['_token']);
        unset($input['submit']);
        ProductModel::where('product_id',$input['product_id'])->update($input);
        toastr()->success('Updated');
        return redirect('table');

        //metho 3
        // $searchInput['product_category_id'] = $input['product_category_id'];
        // ProductCategory::updateorcreate($searchInput,$input);
        // return redirect('Product_Category');
    }

    public function destroy($id)
    {
        ProductModel::where('product_id',$id)->delete();
        toastr()->error('Deleted');
        return redirect('product');
    }

    // public function destroy(Request $request, $id) {

    //     $image = ProductModel::find($request->id);

    //     unlink("uploads/".$image->image);

    //     ProductModel::where("image", $image->id)->delete();

    //     return redirect('product');

    // }

    public function upload(Request $request){
        // echo "<pre>";
        // print_r($request->all());
        $filename = time()."-image.".$request->file('image')->getClientOriginalExtension();

        echo $request->file('image')->storeas('uploads',$filename);
    }
}
