@extends('dashboard')
@section('content')

<div class="page-breadcrumb bg-white">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h3 class="page-title">Products</h3>
        </div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               <div class="card-header">Category</div>

                  <div class="card-body">

                      <h2>Add Category</h2>
                      <form action="{{url('category/store')}}" method="POST" id="form" enctype="multipart/form-data">
                        @csrf
                            <div class="form-group">
                             <label>Category Name</label>
                             <input type="text" name="category_name" class="form-control" placeholder="Category Name">
                             <small class="text-danger">{{$errors->first('category_name')}}</small>
                            </div>

                            <div class="form-group">
                                <input type="submit" name="submit" value="Insert category">
                            </div>

                      </form>
                      <table class="table table-bordered" width="100%" style="text-align: center">
                        <thead>
                            <td>Name</td>
                            <td>Action</td>
                        </thead>
                        <tbody>
                            @if ($product->isNotEmpty())
                              @foreach ($product as $pro)
                                  <tr>
                                  <td>{{$pro->category_name}}</td>
                                  {{-- <td>
                                      <img src="{{asset('uploads/'.$pro->image)}}" width="70px" height="70px">
                                  </td> --}}
                                  <td><a href="{{url('category/edit')}}/{{$pro->category_id}}" class="btn btn-primary">Update</a>
                                      <a href="{{url('category/delete')}}/{{$pro->category_id}}" class="btn btn-danger">Delete</a>
                                  </td>
                                  </tr>
                              @endforeach
                            @endif
                        </tbody>
                    </table>

                  </div>
               </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

@endsection

