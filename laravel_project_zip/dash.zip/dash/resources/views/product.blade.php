@extends('dashboard')
@section('content')

<div class="page-breadcrumb bg-white">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h3 class="page-title">Products</h3>
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                    <div class="card-header"><h2>Product</h2> </div>

                        <div class="card-body">

                            <h3>Add Product</h3>
                            <form action="{{url('product\store')}}" method="POST" id="form" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group">
                                    <label for="category">Category </label>

                                    <select class="form-control" name="category_id">
                                        <option value="">Select Category</option>
                                        @foreach ($product as $category )
                                    <option value="{{$category->category_id}}">{{ $category->category_name}}</option>
                                    @endforeach


                                    </select>
                                    {{-- <input type="text" name="category_name" class="form-control"> --}}
                                    {{-- <small class="text-danger">{{$errors->first('category_id')}}</small> --}}
                                </div>

                                <div class="form-group">
                                    <label>Product Name</label>
                                    <input type="text" name="product_name" class="form-control" placeholder="Product Name">
                                    <small class="text-danger">{{$errors->first('product name')}}</small>
                                    </div>

                                    <div class="form-group">
                                    <label>Product Description</label>
                                    <textarea type="text" name="product_description" class="form-control"></textarea>
                                    {{-- <small class="text-danger">{{$errors->first('product description')}}</small> --}}
                                    </div>
                                    <div class="form-group">
                                        <label for="">File</label>
                                        <input type="file" name="image" id="" class="form-control" placeholder="" aria-describedby="helpId">
                                    </div>

                                    <div class="form-group">
                                        <input type="submit" name="submit" value="Insert Product">
                                    </div>

                            </form>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{{-- <script>
 $(document).ready(function() {
      $("#form").validate({
    rules: {
        product_category_name:{
          minlength:3,
        },
      },
    messages: {
        product_category_name: "Please enter atleast 3 character."
    }
  });
});
</script> --}}
@endsection

