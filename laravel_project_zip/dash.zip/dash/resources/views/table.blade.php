@extends('dashboard')
@section('content')

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               <div class="card-header">Product Category</div>

                  <div class="card-body">
                      <hr>
                      <table class="table table-bordered" width="100%">
                          <thead>
                            <td>Product Category</td>
                              <td>Product Name</td>
                              <td>Product image</td>
                              <td>Description</td>
                              <td>Status</td>
                              <td>Action</td>
                          </thead>
                          <tbody>
                              @if ($product->isNotEmpty())
                                @foreach ($product as $pro)
                                    <tr>
                                        <td>{{$pro->getCategory->category_name}}</td>
                                    <td>{{$pro->product_name}}</td>
                                    <td>
                                        <img src="{{asset('uploads/'.$pro->image)}}" width="70px" height="70px">
                                    </td>

                                    <td>{{$pro->product_description}}</td>
                                    <td>{{$pro->status}}</td>
                                    <td style="text-align: center"><a href="{{url('product/edit')}}/{{$pro->product_id}}" class="btn btn-primary">Update</a>
                                        <a href="{{url('product/delete')}}/{{$pro->product_id}}" class="btn btn-danger">Delete</a>
                                    </td>
                                    </tr>
                                @endforeach
                              @endif
                          </tbody>
                      </table>

                  </div>
               </div>
            </div>
        </div>
    </div>
</div>

@endsection

