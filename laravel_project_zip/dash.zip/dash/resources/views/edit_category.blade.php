@extends('dashboard')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               <div class="card-header">Category</div>

                  <div class="card-body">
                      <form action="{{url('category\update')}}" method="POST" id="form">
                        @csrf
                        <input type="hidden" name="category_id" value="{{$product->category_id}}">
                            <div class="form-group">
                             <label>Category Name</label>
                             <input type="text" name="category_name" class="form-control" value="{{$product->category_name}}">
                             {{-- <small class="text-danger">{{$errors->first('product category name')}}</small> --}}
                            </div>



                            <div class="form-group">
                                <input type="submit" name="submit" value="Update Product">
                            </div>

                      </form>
                  </div>
               </div>
            </div>
        </div>
    </div>
</div>
<script>
 $(document).ready(function() {
      $("#form").validate({
    rules: {
        product_category_name:{
          minlength:3,
        },
      },
    messages: {
        product_category_name: "Please enter atleast 3 character."
    }
  });
});
</script>
@endsection
